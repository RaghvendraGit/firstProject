#!/bin/bash
region=""
cluster=""

parse_params() {
  local argcount="$#"
  for i in `seq ${argcount}`; do
    eval arg=\$$i
    param="`echo ${arg} | awk -F '=' '{print $1}' | sed -e 's|--||'`"
    value="`echo ${arg} | awk -F '=' '{print $2}'`"
    case "${param}" in
      region)
        eval $param="${value}"
        ;;
      cluster)
        eval $param="${value}"
        ;;
      *)
        ;;
    esac
  done
}

do_CI() {
  # Getting service definitions from the cluster
  local serviceDefinitions=(`aws ecs list-services --region $region --cluster $cluster | jq -r '. | .serviceArns[]' | sed -r 's/.*service\/([a-z,-]*)/\1/' | sort | uniq`)
  local serviceCounts=()
  local totalTasksCount=0
  local i=1

  i=1
  for serviceDefinition in ${serviceDefinitions[*]}; do
    local count=`aws ecs describe-services --region $region --cluster $cluster --service $serviceDefinition | jq -r '. | .services[].runningCount'`
    printf "`date +'%m/%d/%Y - %H:%M:%S'` - Service: ${serviceDefinition} - Task Count: ${count}.\n" >> /root/tools/ecs_ci_cd.execution.log
    serviceCounts[$((i++))]="${serviceDefinition} ${count}"
    serviceCounts[0]="$((i-1))"
    totalTasksCount=$((totalTasksCount + count))
  done

  printf "`date +'%m/%d/%Y - %H:%M:%S'` - Total Tasks Count: ${totalTasksCount}.\n" >> /root/tools/ecs_ci_cd.execution.log
  printf "`date +'%m/%d/%Y - %H:%M:%S'` - Start winding down tasks by updating service count to 0.\n" >> /root/tools/ecs_ci_cd.execution.log
  for serviceDefinition in ${serviceDefinitions[*]}; do
    printf "`date +'%m/%d/%Y - %H:%M:%S'` - Start ECS Update Service set desired count = 0.\n" >> /root/tools/$serviceDefinition.execution.log
    aws ecs update-service --region $region --cluster $cluster --service $serviceDefinition --desired-count 0 >> /root/tools/$serviceDefinition.execution.log
    printf "`date +'%m/%d/%Y - %H:%M:%S'` - End ECS Update Service.\n" >> /root/tools/$serviceDefinition.execution.log
    sleep 1
  done

  printf "`date +'%m/%d/%Y - %H:%M:%S'` - Start checking to make sure all tasks are down to 0.\n" >> /root/tools/ecs_ci_cd.execution.log
  runningCount=1
  while [[ $((runningCount)) > 0 ]]; do
    # Reset runningCount to 0 for each execution
    runningCount=0
    for serviceDefinition in ${serviceDefinitions[*]}; do
      runningCount=$((runningCount + `aws ecs describe-services --region $region --cluster $cluster --service $serviceDefinition | jq -r '. | .services[].runningCount'`))
    done
    printf "`date +'%m/%d/%Y - %H:%M:%S'` - Running tasks: $runningCount.\n" >> /root/tools/ecs_ci_cd.execution.log
    sleep 30
  done

  printf "`date +'%m/%d/%Y - %H:%M:%S'` - Start bringing up all tasks back to its original count.\n" >> /root/tools/ecs_ci_cd.execution.log
  i=1
  while [[ $i < $((serviceCounts[0] + 1)) ]]; do
    serviceCount=(${serviceCounts[$((i++))]})
    printf "`date +'%m/%d/%Y - %H:%M:%S'` - Start ECS Update Service set desired count = ${serviceCount[1]}.\n" >> /root/tools/$serviceDefinition.execution.log
    aws ecs update-service --region $region --cluster $cluster --service ${serviceCount[0]} --desired-count ${serviceCount[1]} >> /root/tools/$serviceDefinition.execution.log
    printf "`date +'%m/%d/%Y - %H:%M:%S'` - End ECS Update Service.\n" >> /root/tools/$serviceDefinition.execution.log
  done

  printf "`date +'%m/%d/%Y - %H:%M:%S'` - Start checking to make sure all tasks are back up.\n" >> /root/tools/ecs_ci_cd.execution.log
  runningCount=0
  while [[ $((runningCount)) < $((totalTasksCount)) ]]; do
    sleep 30
    runningCount=0
    for serviceDefinition in ${serviceDefinitions[*]}; do
      local count=`aws ecs describe-services --region $region --cluster $cluster --service $serviceDefinition | jq -r '. | .services[].runningCount'`
      printf "`date +'%m/%d/%Y - %H:%M:%S'` - Running tasks: $serviceDefinition - $count.\n" >> /root/tools/ecs_ci_cd.execution.log
      runningCount=$((runningCount + count))
    done
    printf "`date +'%m/%d/%Y - %H:%M:%S'` - Running tasks: $runningCount.\n" >> /root/tools/ecs_ci_cd.execution.log
  done
}

parse_params $*

if [[ ("" != $region) && ("" != $cluster) ]]; then
  printf "`date +'%m/%d/%Y - %H:%M:%S'` - Start ECS CI CD Execution.\n" >> /root/tools/ecs_ci_cd.execution.log
  do_CI
  printf "`date +'%m/%d/%Y - %H:%M:%S'` - End ECS CI CD Execution.\n" >> /root/tools/ecs_ci_cd.execution.log
fi
