docker ps -a |  grep "artifactory.dowjones.io" | awk '{print $1}' | xargs docker stop -f
docker ps -a |  grep "artifactory.dowjones.io" | awk '{print $1}' | xargs docker rm -f
docker images |  grep "artifactory.dowjones.io" | awk '{print $3}' | xargs docker rmi -f
