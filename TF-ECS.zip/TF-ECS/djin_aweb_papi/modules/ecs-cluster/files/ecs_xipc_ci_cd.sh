#!/bin/bash
region=""
cluster=""

parse_params() {
  local argcount="$#"
  for i in `seq ${argcount}`; do
    eval arg=\$$i
    param="`echo ${arg} | awk -F '=' '{print $1}' | sed -e 's|--||'`"
    value="`echo ${arg} | awk -F '=' '{print $2}'`"
    case "${param}" in
      region)
        eval $param="${value}"
        ;;
      cluster)
        eval $param="${value}"
        ;;
      *)
        ;;
    esac
  done
}

dockerPull() {
  # List all docker images
  local dockerImages=(`docker images | grep dowjones.io | sed -r 's/(.*)[\ ]*latest.*/\1/' | sed -r 's/ //g'`)

  # Pull all docker images
  for dockerImage in ${dockerImages[*]}; do
    docker pull $dockerImage
  done
}

do_xipc_ci() {
  # Get initial XIPC task from cloud-init-log (cat /var/log/cloud-init-output.log)
  local ecsStartTask=`cat /var/log/cloud-init-output.log | grep 'aws ecs start-task' | sed -r 's/\+\ (.*)/\1/'`
  local xipcTaskArn=`cat /var/log/cloud-init-output.log | grep taskArn | sed -r 's/.*"(arn:aws.*)",/\1/' | sort | uniq`

  # Locate XIPC task ARN
  local taskArnsList=(`aws ecs list-tasks --region $region --cluster $cluster | jq -r '. | .taskArns[]' | sort | uniq`)
  for taskArn in ${taskArnsList[*]}; do
    if [[ '' != `aws ecs describe-tasks --region $region --cluster $cluster --task $taskArn | jq -r '.tasks[].group' | grep -i rts` ]]; then
      xipcTaskArn=$taskArn
    fi
  done

  # Stop existing XIPC task and check on the existing task make sure it's stopped
  aws ecs stop-task --region $region --cluster $cluster --task $xipcTaskArn
  while [[ 'STOPPED' != `aws ecs describe-tasks --region $region --cluster $cluster --task $xipcTaskArn | jq -r '.tasks[].lastStatus'` ]]; do
    printf "XIPC task last status is not STOPPED\n"
    sleep 30
  done

  # Start XIPC task again
  eval $ecsStartTask
}

parse_params $*

if [[ ("" != $region) && ("" != $cluster) ]]; then
  printf "`date +'%m/%d/%Y - %H:%M:%S'` - Start ECS XIPC CI CD Execution.\n" >> /root/tools/ecs_ci_cd.execution.log
  do_xipc_ci
  printf "`date +'%m/%d/%Y - %H:%M:%S'` - End ECS XIPC CI CD Execution.\n" >> /root/tools/ecs_ci_cd.execution.log
fi
