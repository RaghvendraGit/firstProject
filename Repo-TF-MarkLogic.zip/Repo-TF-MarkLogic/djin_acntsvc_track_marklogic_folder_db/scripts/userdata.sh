#!/bin/bash -v
set -x

# set hostname
hostnamectl set-hostname "${terraform_hostname}.${terraform_domain}" --static
echo "preserve_hostname: true" >> /etc/cloud/cloud.cfg

${chef_max_sh}

# Generating ssh keys for search user and making ssh password-less for self

su - search -c "echo | ssh-keygen -P '' -t rsa" 
su - search -c "cat .ssh/id_rsa.pub >> .ssh/authorized_keys"
su - search -c "chmod 640 .ssh/authorized_keys"