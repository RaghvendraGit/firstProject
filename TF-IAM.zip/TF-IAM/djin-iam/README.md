# djin-iam

This is the official IAM repository for PIB landing zones :

- pibbuild
- pibnonproddsv, pibproddsv, pibstagdsv
- pibnonprodusr, pibprodusr, pibstagusr
- pibnonprodcntsvc, pibprodcntsvc, pibstagcntsvc
- pibnonprodweb, pibprodweb, pibstagweb
- pibnonprodcontentmgmt, pibprodcontentmgmt, pibstagcontentmgmt
- pibnonproddatamgmt, pibproddatamgmt, pibstagdatamgmt
- pibpnonprodidentity, pibprodidentity, pibstagidentity
- pibnonprodnewswires, pibprodnewswires, pibstagnewswires
- pibnonprodingest, pibprodingest, pibstagingest

The workflow is driven strictly by its `folder structure` and a [Jenkinsfile pipeline job](Jenkins/Jenkinsfile). The workflow is a pull request model where every PR is automatically tested (terraform get/validate/plan) by [djin-iam pr checker](Jenkins/Jenkinsfile_PrBuilder) and then approved, merged and synced with AWS by EP.

PIB folks creating/modifying IAM, read this prior to creating any PR's.
- [Instructions](Docs/CONTRIBUTING.md) for creating PR.
- [Folder Structure](Docs/FOLDERSTRUCTURE.md) for info on where your terraform goes.
- [IAM Standards](https://wiki.dowjones.net/display/EMGTECH/LZ+IAM+RoleTerraform+Workflow) to follow in every PR.  


The Jenkinsfile is coded to combine all files in the base folder and a specific account folder, and then run:

```HCL
terraform init (artifactory)
terraform get -update
terraform validate
terraform plan
terraform apply
```
Once aproved by EP , IAM workflow can be used to upload and sync IAM with new landing zones by executing this [jenkins job](https://10.146.84.103/view/utils/job/iam-workflow/) . EP is responsible for running it.

EP folks can head over [here](Docs/EP_INTERNAL.md) for approval steps.
