All files in env folders will be pushed to all nonprod/prod/stag env in all PIB lz's
