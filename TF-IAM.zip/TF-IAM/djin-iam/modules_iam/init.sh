#!/bin/bash -e
#DO NOT TOUCH/DELETE THIS file

if [ -z $1 ]
then
    echo "ERROR: This script requires a unique subpath for storing Terraform state files in Artifactory."
    exit 1
fi

$2 init \
  -backend=true \
  -backend-config="username=djin-terraform-iamsg" \
  -backend-config="password=cMY-mNm-v2e-AhUcMY-mNm-v2e-AhU" \
  -backend-config="url=https://artifactory.dowjones.io/artifactory/" \
  -backend-config="repo=djin-terraform-iamsg" \
  -get=true \
  -backend-config="subpath=$1" \
  -backend-config="skip_cert_verification=true" \
  -input=false
