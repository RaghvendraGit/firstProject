# CONTRIBUTING

## Pre-requisites
To create iam roles for your application, open a pull request with **app_name.tf** files in the respective account folder :

`global naming convention : snake_case`

- *nonprod*: development and/or integration iam roles
- *prod*: production iam roles
- *stag*: staging iam roles

We will reject any pull request that dont follow the following rules every **app_name.tf** :

- `snake_case` for all naming convention. Follow [sample_app.tf](../accounts/build/sample_app.tf) for example.
- All resources must be `properly tagged` with:
    - servicename
    - owner/s
- Terraform files cant have any other resource than iam roles
- nonprod account folder cant have prod iam roles or vice versa
- all app_name.tf should start with a comments/links to the architectural diagram/network diagram/infosec approval of the application iam roles.

## Modules
The following modules are created by EP and these are global common security groups and are available within all accounts to be used in your infrastructure.

#### dj-iam Shared Repo
There is a shared repository that inherits the legacy Goodson workflow policy documents - https://github.dowjones.net/Terraform/dj-iam

#### Local Modules (Addresses Folder)
The modules_iam folder contains all modules that are owned by the Engineering Productivity.
