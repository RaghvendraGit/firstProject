# More details

There are several components of this design.  The core concept is the utilization of modules to produce policy documents, the use of a 'base' folder for all terraform resources shared across accounts, and a series of account-specific folders that hold terraform files that are unique to an AWS account.

**Steps before Approval** :

- Make sure the PR checker has approved the PR  ![PRApproval](../images/approved.png)
- Check to make sure the PR follows the [Best Practices](https://wiki.dowjones.net/display/EMGTECH/LZ+IAM+RoleTerraform+Workflow)
- Verify that the tf has comments for all resources/variables and is using pre-defined variables whereever possible.
- Challenge any wide open access to resources if the action is within create/delete. Reccommend using [conditions](https://github.dowjones.net/Terraform/djin-iam/blob/master/accounts/cntsvc/cntsvcnonprod/llsearch.tf#L55-L63) in necessary scenarios like that.
- Verify that the names for the shared/modulefile and account/varfile are semantic and common (e.g - shared/relevancy.tf , nonprod/relevancy_var.tf)
- Verify for any file addition to shared folder, **the respective var file is added to all three environments** folder

## Terraform Folders

### Base Folder
This folder contains all terraform resources that are universally available.  The AWS region is designated as us-east-1, as IAM resources are not region-specific.  The base\_modules file contains all modules that only need to be invoked once.

### Account Folders
These folders are named for each Landing Zone account, and contain all accounts-specific variables, modules, policies, and roles.
