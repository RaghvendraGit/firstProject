# DJIN-IAM FOLDER STRUCTURE

djin-iam has to the following folders of note :

- modules_iam : All module implementations go here under a semantic subfolder with [README.md](modules_iam/README.md)
- base
    - base_main : variables declared here are available in all accounts
    - base_modules : References to modules here push them to all accounts
    - base_policies : Policies declared here are available in all accounts
    - base_roles : Roles declared here are available in all accounts
- accounts
    - *lz*
        - *lznonprod* : Terraform files for nonprod for the lz
        - *lzprod* : Terraform files for prod for the lz
        - *lzstag* : Terraform files for stag for the lz
        - *shared* : Terraform files for common terraform for this entire lz(all env)
- env
    - nonprod : Terraform files for nonprod for all lz's
    - prod : Terraform files for prod for all lz's
    - stag : Terraform files for stag for all lz's

## Pre-requisites
To create iam roles for your application, open a pull request with **app_name.tf** files in the respective account folder :

`global naming convention : snake_case`

- *nonprod*: development and/or integration iam roles
- *prod*: production iam roles
- *stag*: staging iam roles

We will reject any pull request that dont follow the following rules every **app_name.tf** :

- `snake_case` for all naming convention. Follow [sample_app.tf](../accounts/build/sample_app.tf) for example.
- All resources must be `properly tagged` with:
    - servicename
    - owner/s
- Terraform files cant have any other resource than iam roles
- nonprod account folder cant have prod iam roles or vice versa
- all app_name.tf should start with a comments/links to the architectural diagram/network diagram/infosec approval of the application iam roles.

## Modules
The following modules are created by EP and these are global common security groups and are available within all accounts to be used in your infrastructure.

#### dj-iam Shared Repo
There is a shared repository that inherits the legacy Goodson workflow policy documents - https://github.dowjones.net/Terraform/dj-iam

#### Local Modules (Addresses Folder)
The modules_iam folder contains all modules that are owned by the Engineering Productivity.
